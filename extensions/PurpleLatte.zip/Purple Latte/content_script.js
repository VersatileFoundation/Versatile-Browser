(function () {

    if (window.purpleLatteLoaded) return;
    window.purpleLatteLoaded = true;

    const launcher = document.createElement("div");

    launcher.innerHTML = `
        <div style="
            display:flex;
            flex-direction:column;
            align-items:center;
            justify-content:center;
            line-height:1;
        ">
            <div style="font-size:30px;">🎮</div>

            <div style="
                font-size:9px;
                margin-top:2px;
                font-weight:bold;
                letter-spacing:0.5px;
            ">
                LATTE
            </div>
        </div>
    `;

    launcher.title = "Open Purple Latte";

    launcher.style.position = "fixed";
    launcher.style.bottom = "25px";
    launcher.style.left = "25px";
    launcher.style.width = "78px";
    launcher.style.height = "78px";
    launcher.style.borderRadius = "24px";
    launcher.style.background = "rgba(106,13,173,0.92)";
    launcher.style.display = "flex";
    launcher.style.alignItems = "center";
    launcher.style.justifyContent = "center";
    launcher.style.cursor = "pointer";
    launcher.style.zIndex = "999999";
    launcher.style.backdropFilter = "blur(20px)";
    launcher.style.boxShadow = "0 10px 30px rgba(0,0,0,0.45)";
    launcher.style.transition = "0.25s";
    launcher.style.color = "white";
    launcher.style.fontFamily = "Arial, sans-serif";
    launcher.style.userSelect = "none";

    launcher.onmouseenter = () => {
        launcher.style.transform = "scale(1.08)";
    };

    launcher.onmouseleave = () => {
        launcher.style.transform = "scale(1)";
    };

    document.body.appendChild(launcher);

    const overlay = document.createElement("div");

    overlay.style.position = "fixed";
    overlay.style.inset = "0";
    overlay.style.background = "rgba(10,10,10,0.88)";
    overlay.style.backdropFilter = "blur(18px)";
    overlay.style.zIndex = "999998";
    overlay.style.display = "none";
    overlay.style.flexDirection = "column";
    overlay.style.opacity = "0";
    overlay.style.transition = "0.3s";

    overlay.innerHTML = `

    <div style="
        padding:16px;
        text-align:center;
        background:#6a0dad;
        color:white;
        font-family:Arial,sans-serif;
        font-size:24px;
        font-weight:bold;
        position:relative;
        flex-shrink:0;
    ">
        🎮 Purple Latte Game Hub

        <button id="purpleExit" style="
            position:absolute;
            right:15px;
            top:12px;
            width:40px;
            height:40px;
            border:none;
            border-radius:12px;
            background:#1e1e1e;
            color:white;
            cursor:pointer;
            font-size:18px;
        ">
            ✕
        </button>
    </div>

    <div id="purpleMenu" style="
        display:flex;
        flex-direction:column;
        gap:8px;
        padding:16px;
        overflow-y:auto;
        flex:1;
    ">

        <button class="purpleBtn" data-url="https://thevortexdev.github.io/untitled-zombie-danmaku-game-demo2/">
            Untitled Zombie Bullet Hell Gaem
        </button>

        <button class="purpleBtn" data-url="https://thevortexdev.github.io/untitled-zombie-tower-defense-gaem-test2/">
            Untitled Zombie Tower Defense Gaem
        </button>

        <button class="purpleBtn" data-url="https://turbowarp.org/863955102/embed?interpolate&hqpen&clones=Infinity&limitless&fps=60">
            Untitled Zombie Gaem
        </button>

        <button class="purpleBtn" data-url="https://scratch.mit.edu/projects/1210906706/embed">
            QuickPush! For PC
        </button>

        <button class="purpleBtn" data-url="https://scratch.mit.edu/projects/867688425/embed">
            Fruit Ninja Clone
        </button>

        <button class="purpleBtn" data-url="https://scratch.mit.edu/projects/916156687/fullscreen/">
            Projectile Clash!
        </button>

    </div>

    <div id="purpleControls" style="
        display:none;
        background:#6a0dad;
        padding:10px;
        gap:10px;
        flex-shrink:0;
        justify-content:center;
    ">

        <button id="purpleBack">
            ⬅ Back
        </button>

        <button id="purpleTab">
            🚀 Open in Tab
        </button>

    </div>

    <iframe id="purpleFrame" style="
        flex:1;
        width:100%;
        border:none;
        background:black;
        display:none;
    "></iframe>

    `;

    document.body.appendChild(overlay);

    const style = document.createElement("style");

    style.innerHTML = `

    .purpleBtn {
        padding:14px;
        background:#1e1e1e;
        color:white;
        border:1px solid #6a0dad;
        border-radius:14px;
        cursor:pointer;
        font-size:15px;
        transition:0.2s;
    }

    .purpleBtn:hover {
        background:#6a0dad;
        transform:scale(1.01);
    }

    #purpleBack,
    #purpleTab,
    #purpleExit {

        padding:12px 16px;
        background:#1e1e1e;
        color:white;
        border:none;
        border-radius:12px;
        cursor:pointer;
        transition:0.2s;
    }

    #purpleBack:hover,
    #purpleTab:hover,
    #purpleExit:hover {

        background:#2b2b2b;
    }

    `;

    document.head.appendChild(style);

    const frame = overlay.querySelector("#purpleFrame");
    const menu = overlay.querySelector("#purpleMenu");
    const controls = overlay.querySelector("#purpleControls");

    let currentURL = "";

    function resetHub() {

        frame.src = "";

        frame.style.display = "none";

        menu.style.display = "flex";

        controls.style.display = "none";

        currentURL = "";
    }

    function openOverlay() {

        overlay.style.display = "flex";

        requestAnimationFrame(() => {
            overlay.style.opacity = "1";
        });
    }

    function closeOverlay() {

        overlay.style.opacity = "0";

        setTimeout(() => {

            overlay.style.display = "none";

            resetHub();

        }, 300);
    }

    launcher.onclick = () => {

        openOverlay();
    };

    overlay.querySelectorAll(".purpleBtn").forEach(btn => {

        btn.onclick = () => {

            currentURL = btn.dataset.url;

            frame.src = currentURL;

            frame.style.display = "block";

            menu.style.display = "none";

            controls.style.display = "flex";
        };
    });

    overlay.querySelector("#purpleBack").onclick = () => {

        resetHub();
    };

    overlay.querySelector("#purpleTab").onclick = () => {

        if (currentURL) {

            window.open(currentURL, "_blank");
        }
    };

    overlay.querySelector("#purpleExit").onclick = () => {

        closeOverlay();
    };

    overlay.addEventListener("click", (e) => {

        if (e.target === overlay) {

            closeOverlay();
        }
    });

    document.addEventListener("keydown", (e) => {

        if (e.key === "Escape") {

            closeOverlay();
        }
    });

})();