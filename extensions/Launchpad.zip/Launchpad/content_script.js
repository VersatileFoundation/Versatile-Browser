(function () {

    if (window.launchpadLoaded) return;
    window.launchpadLoaded = true;

    const STORAGE_KEY = "launchpad_apps";
    let apps = [];

    const style = document.createElement("style");

    style.innerHTML = `

    #launchpadButton {
        position: fixed;
        bottom: 25px;
        right: 25px;
        width: 68px;
        height: 68px;
        border-radius: 24px;
        background: rgba(25,25,25,0.88);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255,255,255,0.12);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: 0 10px 30px rgba(0,0,0,0.45);
        transition: 0.25s;
        font-size: 30px;
        color: white;
        font-family: sans-serif;
    }

    #launchpadButton:hover {
        transform: scale(1.08);
    }

    #addButton {
        position: fixed;
        bottom: 25px;
        right: 25px;
        width: 62px;
        height: 62px;
        border-radius: 22px;
        background: rgba(50,50,50,0.92);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255,255,255,0.12);
        z-index: 999998;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: 0 10px 30px rgba(0,0,0,0.45);
        transition:
            transform 0.35s cubic-bezier(.2,.8,.2,1),
            opacity 0.25s;
        font-size: 34px;
        color: white;
        opacity: 0;
        pointer-events: none;
        transform: translateY(0px) scale(0.7);
    }

    #addButton.show {
        opacity: 1;
        pointer-events: auto;
        transform: translateY(-90px) scale(1);
    }

    #addButton:hover {
        transform: translateY(-90px) scale(1.08);
    }

    #launchpadOverlay {
        position: fixed;
        inset: 0;
        background: rgba(8,8,8,0.78);
        backdrop-filter: blur(28px);
        z-index: 999997;
        display: none;
        opacity: 0;
        transition: opacity 0.35s ease;
        overflow-y: auto;
    }

    #launchpadContent {
        transform: translateY(60px) scale(0.95);
        opacity: 0;
        transition: transform 0.45s cubic-bezier(.2,.8,.2,1), opacity 0.35s;
    }

    #launchpadContent.show {
        transform: translateY(0px) scale(1);
        opacity: 1;
    }

    #launchpadGrid {
        width: 90%;
        margin: 80px auto 40px auto;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
        gap: 35px;
    }

    .launchpadApp {
        display: flex;
        flex-direction: column;
        align-items: center;
        color: white;
        cursor: pointer;
        transition: 0.25s;
        user-select: none;
    }

    .launchpadApp:hover {
        transform: scale(1.08);
    }

    .launchpadIcon {
        width: 110px;
        height: 110px;
        border-radius: 30px;
        overflow: hidden;
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.12);
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 12px;
        font-size: 42px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.35);
    }

    .launchpadLabel {
        font-family: sans-serif;
        font-size: 15px;
        text-align: center;
        text-shadow: 0 2px 6px black;
    }

    .deleteBtn {
        margin-top: 10px;
        padding: 8px 14px;
        border: none;
        border-radius: 12px;
        background: rgba(255,0,0,0.2);
        color: white;
        cursor: pointer;
        transition: 0.2s;
    }

    .deleteBtn:hover {
        background: rgba(255,0,0,0.4);
    }

    #launchpadClose {
        position: fixed;
        top: 25px;
        right: 35px;
        color: white;
        font-size: 42px;
        cursor: pointer;
        font-family: sans-serif;
        z-index: 999999;
    }

    #appCreator {
        width: 600px;
        max-width: 90%;
        margin: 0 auto 60px auto;
        background: rgba(20,20,20,0.72);
        backdrop-filter: blur(20px);
        border-radius: 30px;
        padding: 30px;
        color: white;
        font-family: sans-serif;
        border: 1px solid rgba(255,255,255,0.12);

        max-height: 0;
        opacity: 0;
        overflow: hidden;

        transition: max-height 0.45s cubic-bezier(.2,.8,.2,1),
                    opacity 0.35s,
                    padding 0.35s;
    }

    #appCreator.show {
        max-height: 500px;
        opacity: 1;
        padding: 30px;
    }

    .launchInput {
        width: 100%;
        padding: 14px;
        border-radius: 16px;
        border: none;
        outline: none;
        background: rgba(255,255,255,0.08);
        color: white;
        margin-bottom: 18px;
        font-size: 15px;
        box-sizing: border-box;
    }

    #createAppBtn {
        width: 100%;
        padding: 15px;
        border: none;
        border-radius: 18px;
        background: linear-gradient(135deg,#3b82f6,#2563eb);
        color: white;
        font-size: 16px;
        cursor: pointer;
        transition: 0.25s;
    }

    #createAppBtn:hover {
        transform: scale(1.02);
    }
    `;

    document.head.appendChild(style);

    const launchpadButton = document.createElement("div");
    launchpadButton.id = "launchpadButton";
    launchpadButton.innerHTML = "🚀";

    const addButton = document.createElement("div");
    addButton.id = "addButton";
    addButton.innerHTML = "+";

    const overlay = document.createElement("div");
    overlay.id = "launchpadOverlay";

    const content = document.createElement("div");
    content.id = "launchpadContent";

    const close = document.createElement("div");
    close.id = "launchpadClose";
    close.innerHTML = "✕";

    const grid = document.createElement("div");
    grid.id = "launchpadGrid";

    const creator = document.createElement("div");
    creator.id = "appCreator";

    creator.innerHTML = `
        <h1>Add Website App</h1>
        <input class="launchInput" id="appName" placeholder="App Name">
        <input class="launchInput" id="appURL" placeholder="https://example.com">
        <input class="launchInput" id="appIcon" placeholder="Emoji or Image URL">
        <button id="createAppBtn">Create App</button>
    `;

    content.appendChild(close);
    content.appendChild(grid);
    content.appendChild(creator);

    overlay.appendChild(content);
    document.body.appendChild(overlay);
    document.body.appendChild(addButton);
    document.body.appendChild(launchpadButton);

    function saveApps() {
        try {
            const data = JSON.stringify(apps);
            localStorage.setItem(STORAGE_KEY, data);

            if (typeof chrome !== "undefined" && chrome.storage?.local) {
                chrome.storage.local.set({ [STORAGE_KEY]: apps });
            }
        } catch (err) {
            console.error(err);
        }
    }

    function loadApps() {
        try {
            if (typeof chrome !== "undefined" && chrome.storage?.local) {
                chrome.storage.local.get([STORAGE_KEY], (result) => {
                    apps = result?.[STORAGE_KEY] || JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
                    renderApps();
                });
            } else {
                apps = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
                renderApps();
            }
        } catch (err) {
            apps = [];
            renderApps();
        }
    }

    function renderApps() {
        grid.innerHTML = "";

        apps.forEach((app, index) => {

            const appDiv = document.createElement("div");
            appDiv.className = "launchpadApp";

            const icon = document.createElement("div");
            icon.className = "launchpadIcon";

            if (app.icon?.startsWith("http")) {
                const img = document.createElement("img");
                img.src = app.icon;
                icon.appendChild(img);
            } else {
                icon.innerHTML = app.icon || "🌐";
            }

            const label = document.createElement("div");
            label.className = "launchpadLabel";
            label.textContent = app.name;

            const del = document.createElement("button");
            del.className = "deleteBtn";
            del.innerText = "Delete";

            del.onclick = (e) => {
                e.stopPropagation();
                apps.splice(index, 1);
                saveApps();
                renderApps();
            };

            appDiv.onclick = () => {

                let finalURL = app.url.trim();

                if (!finalURL.startsWith("http://") && !finalURL.startsWith("https://")) {
                    finalURL = "https://" + finalURL;
                }

                window.location.href = finalURL;
            };

            appDiv.appendChild(icon);
            appDiv.appendChild(label);
            appDiv.appendChild(del);
            grid.appendChild(appDiv);
        });
    }

    function openLaunchpad() {
        overlay.style.display = "block";

        requestAnimationFrame(() => {
            overlay.style.opacity = "1";
            content.classList.add("show");
            addButton.classList.add("show");
        });
    }

    function closeLaunchpad() {
        overlay.style.opacity = "0";
        content.classList.remove("show");
        addButton.classList.remove("show");
        creator.classList.remove("show");

        setTimeout(() => {
            overlay.style.display = "none";
        }, 350);
    }

    launchpadButton.onclick = openLaunchpad;
    close.onclick = closeLaunchpad;

    overlay.addEventListener("click", (e) => {
        if (e.target === overlay) closeLaunchpad();
    });

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") closeLaunchpad();
    });

    addButton.onclick = () => {
        creator.classList.toggle("show");
    };

    document.getElementById("createAppBtn").onclick = () => {

        const name = document.getElementById("appName").value.trim();
        const url = document.getElementById("appURL").value.trim();
        const icon = document.getElementById("appIcon").value.trim();

        if (!name || !url) return alert("Enter a name and URL.");

        apps.push({ name, url, icon: icon || "🌐" });

        saveApps();
        renderApps();

        creator.classList.remove("show");

        document.getElementById("appName").value = "";
        document.getElementById("appURL").value = "";
        document.getElementById("appIcon").value = "";
    };

    loadApps();

})();