(function () {

    if (window.sebbarlyLoaded) return;
    window.sebbarlyLoaded = true;

    let selectedText = "";

    function detectTheme() {

        const bodyStyle =
            getComputedStyle(document.body);

        const rootStyle =
            getComputedStyle(document.documentElement);

        const background =
            bodyStyle.backgroundColor ||
            rootStyle.backgroundColor ||
            "#121212";

        const text =
            bodyStyle.color ||
            rootStyle.color ||
            "#ffffff";

        function brighten(rgb, amount) {

            const nums =
                rgb.match(/\d+/g);

            if (!nums || nums.length < 3)
                return rgb;

            let r =
                Math.min(
                    255,
                    parseInt(nums[0]) + amount
                );

            let g =
                Math.min(
                    255,
                    parseInt(nums[1]) + amount
                );

            let b =
                Math.min(
                    255,
                    parseInt(nums[2]) + amount
                );

            return `rgb(${r}, ${g}, ${b})`;
        }

        function darken(rgb, amount) {

            const nums =
                rgb.match(/\d+/g);

            if (!nums || nums.length < 3)
                return rgb;

            let r =
                Math.max(
                    0,
                    parseInt(nums[0]) - amount
                );

            let g =
                Math.max(
                    0,
                    parseInt(nums[1]) - amount
                );

            let b =
                Math.max(
                    0,
                    parseInt(nums[2]) - amount
                );

            return `rgb(${r}, ${g}, ${b})`;
        }

        const isDark =
            window.matchMedia(
                "(prefers-color-scheme: dark)"
            ).matches;

        const card =
            isDark
            ? brighten(background, 12)
            : darken(background, 12);

        const card2 =
            isDark
            ? brighten(background, 20)
            : darken(background, 20);

        const accent =
            rootStyle.getPropertyValue(
                "--accent-color"
            ).trim()
            ||
            rootStyle.getPropertyValue(
                "--theme-color"
            ).trim()
            ||
            "#3b82f6";

        return {

            panel: background,
            card: card,
            card2: card2,
            text: text,

            subtle:
                isDark
                ? "rgba(255,255,255,0.7)"
                : "rgba(0,0,0,0.65)",

            border:
                isDark
                ? "rgba(255,255,255,0.08)"
                : "rgba(0,0,0,0.08)",

            accent: accent,

            green:
                isDark
                ? "#7dff9b"
                : "#137333",

            shadow:
                isDark
                ? "rgba(0,0,0,0.45)"
                : "rgba(0,0,0,0.15)"
        };
    }

    const theme = detectTheme();

    const menu = document.createElement("div");

    menu.style.position = "fixed";
    menu.style.background = theme.panel;
    menu.style.backdropFilter = "blur(20px)";
    menu.style.border =
        "1px solid " + theme.border;
    menu.style.borderRadius = "18px";
    menu.style.padding = "8px";
    menu.style.zIndex = "999999";
    menu.style.display = "none";
    menu.style.boxShadow =
        "0 10px 35px " + theme.shadow;

    menu.innerHTML = `

        <button id="sebFixBtn" style="
            padding:12px 16px;
            border:none;
            border-radius:12px;
            background:${theme.accent};
            color:white;
            cursor:pointer;
            font-size:14px;
            font-family:Arial,sans-serif;
        ">
            ✍️ Seb Help Me
        </button>

    `;

    document.body.appendChild(menu);

    const panel = document.createElement("div");

    panel.style.position = "fixed";
    panel.style.right = "25px";
    panel.style.bottom = "25px";
    panel.style.width = "430px";
    panel.style.maxWidth = "92%";
    panel.style.maxHeight = "80vh";
    panel.style.overflowY = "auto";
    panel.style.background = theme.panel;
    panel.style.backdropFilter = "blur(24px)";
    panel.style.borderRadius = "24px";
    panel.style.padding = "20px";
    panel.style.color = theme.text;
    panel.style.fontFamily = "Arial,sans-serif";
    panel.style.zIndex = "999999";
    panel.style.display = "none";
    panel.style.border =
        "1px solid " + theme.border;
    panel.style.boxShadow =
        "0 10px 45px " + theme.shadow;

    document.body.appendChild(panel);

    document.addEventListener("contextmenu", (e) => {

        const selection =
            window.getSelection().toString().trim();

        if (!selection) {

            menu.style.display = "none";
            return;
        }

        selectedText = selection;

        e.preventDefault();

        menu.style.display = "block";

        menu.style.left = e.pageX + "px";
        menu.style.top = e.pageY + "px";
    });

    document.addEventListener("click", () => {

        menu.style.display = "none";
    });

    async function checkGrammar(text) {

        const response = await fetch(
            "https://api.languagetool.org/v2/check",
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/x-www-form-urlencoded"
                },

                body: new URLSearchParams({
                    text: text,
                    language: "en-US"
                })
            }
        );

        return await response.json();
    }

    function applyCorrections(text, matches) {

        let corrected = text;

        matches
            .slice()
            .reverse()
            .forEach(match => {

                if (
                    match.replacements &&
                    match.replacements.length > 0
                ) {

                    corrected =
                        corrected.slice(
                            0,
                            match.offset
                        ) +
                        match.replacements[0].value +
                        corrected.slice(
                            match.offset +
                            match.length
                        );
                }
            });

        return corrected;
    }

    document
        .getElementById("sebFixBtn")
        .onclick = async () => {

        panel.style.display = "block";

        panel.innerHTML = `

            <div style="
                display:flex;
                justify-content:space-between;
                align-items:center;
                margin-bottom:15px;
            ">

                <h2 style="margin:0;">
                    ✍️ Sebbarly
                </h2>

                <button id="sebClose" style="
                    width:36px;
                    height:36px;
                    border:none;
                    border-radius:12px;
                    background:${theme.card};
                    color:${theme.text};
                    cursor:pointer;
                ">
                    ✕
                </button>

            </div>

            <div style="
                padding:16px;
                border-radius:16px;
                background:${theme.card};
            ">
                Checking grammar...
            </div>

        `;

        try {

            const result =
                await checkGrammar(selectedText);

            const corrected =
                applyCorrections(
                    selectedText,
                    result.matches
                );

            const issues =
                result.matches
                .map(match => {

                    const replacements =
                        match.replacements
                        .slice(0, 3)
                        .map(r => r.value)
                        .join(", ");

                    return `

                        <div style="
                            background:${theme.card};
                            padding:14px;
                            border-radius:16px;
                            margin-bottom:10px;
                        ">

                            <div style="
                                color:${theme.accent};
                                font-weight:bold;
                                margin-bottom:6px;
                            ">
                                ${match.message}
                            </div>

                            <div style="
                                color:${theme.subtle};
                                margin-bottom:6px;
                            ">
                                ${match.context.text}
                            </div>

                            <div style="
                                color:${theme.green};
                            ">
                                Suggestions:
                                ${replacements || "None"}
                            </div>

                        </div>

                    `;
                })
                .join("");

            panel.innerHTML = `

                <div style="
                    display:flex;
                    justify-content:space-between;
                    align-items:center;
                    margin-bottom:15px;
                ">

                    <h2 style="margin:0;">
                        ✍️ Sebbarly
                    </h2>

                    <button id="sebClose" style="
                        width:36px;
                        height:36px;
                        border:none;
                        border-radius:12px;
                        background:${theme.card};
                        color:${theme.text};
                        cursor:pointer;
                    ">
                        ✕
                    </button>

                </div>

                <div style="
                    background:${theme.card};
                    padding:14px;
                    border-radius:18px;
                    margin-bottom:14px;
                ">

                    <div style="
                        color:${theme.subtle};
                        margin-bottom:8px;
                    ">
                        Original
                    </div>

                    ${selectedText}

                </div>

                <div style="
                    background:${theme.card2};
                    padding:14px;
                    border-radius:18px;
                    margin-bottom:14px;
                ">

                    <div style="
                        color:${theme.green};
                        font-weight:bold;
                        margin-bottom:8px;
                    ">
                        Seb's Correction
                    </div>

                    ${corrected}

                </div>

                <div style="
                    margin-bottom:12px;
                    font-size:20px;
                    font-weight:bold;
                ">
                    Issues Found
                </div>

                ${issues || `
                    <div style="
                        background:${theme.card2};
                        padding:14px;
                        border-radius:16px;
                    ">
                        ✅ No issues found.
                    </div>
                `}

                <button id="copySeb" style="
                    margin-top:14px;
                    width:100%;
                    padding:14px;
                    border:none;
                    border-radius:16px;
                    background:${theme.accent};
                    color:white;
                    cursor:pointer;
                    font-size:15px;
                ">
                    📋 Copy Corrected Text
                </button>

            `;

            document
                .getElementById("copySeb")
                .onclick = async () => {

                await navigator.clipboard.writeText(
                    corrected
                );

                const btn =
                    document.getElementById(
                        "copySeb"
                    );

                btn.innerText = "✅ Copied";

                setTimeout(() => {

                    btn.innerText =
                        "📋 Copy Corrected Text";

                }, 1500);
            };

            document
                .getElementById("sebClose")
                .onclick = () => {

                panel.style.display = "none";
            };

        } catch (err) {

            panel.innerHTML = `

                <div style="
                    color:red;
                    font-size:18px;
                ">
                    Sebbarly failed to contact
                    LanguageTool API.
                </div>

            `;

            console.error(err);
        }
    };

})();